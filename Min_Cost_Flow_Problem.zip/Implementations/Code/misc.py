# import gurobipy as gp
# from gurobipy import GRB
# import time
# from misc_ex import example3


# def min_cost_flow_ilp(nodes, edges, cost, capacity, capacity1, demand, plants_n, warehouses_n, customers_n, x, y, z):
#     start_time = time.time()

#     # Suppress output
#     env = gp.Env(empty=True)
#     env.setParam("OutputFlag",0)
#     env.start()

#     model = gp.Model(env=env)

#     ## Ορισμός μεταβλητών απόφασης
#     f = model.addVars(nodes, nodes, vtype=GRB.INTEGER, name='f')  

#     for a in plants_n:
#         model.addConstr(gp.quicksum(f[i,j] for (i, j) in x if i == a) + gp.quicksum(f[i,k] for (i, k) in y if i == a) <= capacity[a])
        
#     for w in warehouses_n:
#         model.addConstr(gp.quicksum(f[i,j] for (i, j) in x if j == w) <= capacity1[w])
        
#     for w in warehouses_n:
#         model.addConstr(gp.quicksum(f[j,k] for (j, k) in z if j == w) == gp.quicksum(f[i,j] for (i, j) in x if j == w))
    
#     for d in customers_n:
#         model.addConstr(gp.quicksum(f[i,k] for (i, k) in y if k == d) + gp.quicksum(f[j,k] for (j, k) in z if k == d) == demand[d])
    
#     ## Αντικειμενική συνάρτηση
#     model.setObjective(gp.quicksum(cost[i,j] * f[i,j] for (i,j) in edges if cost[i,j]), GRB.MINIMIZE)

#     # Επίλυση
#     model.optimize()

#     end_time = time.time()

#     diff = time.gmtime(end_time - start_time)
#     print('\n[Total time used: {} minutes, {} seconds]'.format(diff.tm_min, diff.tm_sec))

#     # Εκτύπωση αποτελεσμάτων
#     try:
#         print(f'\nObjective value found: {model.objVal}')
#     except AttributeError as e:
#         print(f'\nCould not find an objective value. \nTraceback:\n\t{e}')


#     # Βέλτιστη ροή ανά ακμή
#     for (i,j) in edges:
#         print('f[{},{}] = {}'.format(
#             i, j, f[i,j].x
#         ))


# if __name__ == '__main__':

#     print("\n-----------------------------Example_3-----------------------------")
#     min_cost_flow_ilp(*example3())




# capacity3_1 = {(f"p{i+1}", f"w{j+1}"): min(capacities_plants[i], throughput_warehouses[j]) for i in plants for j in warehouses}
    # capacity3_2 = {(f"p{i+1}", f"c{k+1}"): min(capacities_plants[i], demand_customers[k]) for i in plants for k in customers}
    # capacity3_3 = {(f"w{j+1}", f"c{k+1}"): min(throughput_warehouses[j], demand_customers[k]) for j in warehouses for k in customers}

    # capacity3 = {**capacity3_1, **capacity3_2, **capacity3_3}
    
    
    # supply3 = capacities_plants + [0] * len(warehouses) + [-demand for demand in demand_customers]

    # supply3 = {node: supply3[i] for i, node in enumerate(nodes3)}